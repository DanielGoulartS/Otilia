package View;

import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JTable;

public class Janela extends JFrame {

    JTable tabela;

    public Janela(String[][] dados, String[] colunas) {

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        setBounds(200,200,1000, 300);
        
        tabela = new JTable(dados, colunas);
        add(tabela);

        setVisible(true);

    }

}
