package Controller;

import View.Janela;
import Model.Aluno;
import Model.Calculadora;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;

public class NewMain {

    public static void main(String[] args) throws SQLException {

        ArrayList<Aluno> alunos = new ArrayList<>();
        Calculadora boletim = new Calculadora();

        String[][] dados = new String[6][11];
        String[] colunas = {"Modalidade:", "Matricula:", "Nome:", "AV1:", "AV2:",
                            "AV3:", "AVD:", "AVDS:", "AVS", "Simulado:", "Média:"};

        alunos = Aluno.build();

        dados = boletim.converter(alunos);

        JFrame janela = new Janela(dados, colunas);

    }

}
