package Model;

import Model.DAO.AlunoDAO;
import Model.DAO.DAO;
import Model.DAO.NotaDAO;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Aluno {

    int matricula;
    String nome, tipo;
    double av1, av2, av3, avd, avds, avs, simulado;

    public Aluno(int matricula, String nome, String tipo, double av1, double av2, double av3, double avd, double avds, double avs, double simulado) {
        this.matricula = matricula;
        this.nome = nome;
        this.tipo = tipo;
        this.av1 = av1;
        this.av2 = av2;
        this.av3 = av3;
        this.avd = avd;
        this.avds = avds;
        this.avs = avs;
        this.simulado = simulado;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getAv1() {
        return av1;
    }

    public void setAv1(double av1) {
        this.av1 = av1;
    }

    public double getAv2() {
        return av2;
    }

    public void setAv2(double av2) {
        this.av2 = av2;
    }

    public double getAv3() {
        return av3;
    }

    public void setAv3(double av3) {
        this.av3 = av3;
    }

    public double getAvd() {
        return avd;
    }

    public void setAvd(double avd) {
        this.avd = avd;
    }

    public double getAvds() {
        return avds;
    }

    public void setAvds(double avds) {
        this.avds = avds;
    }

    public double getAvs() {
        return avs;
    }

    public void setAvs(double avs) {
        this.avs = avs;
    }

    public double getSimulado() {
        return simulado;
    }

    public void setSimulado(double simulado) {
        this.simulado = simulado;
    }

    public static ArrayList build() throws SQLException {
        DAO aluDAO = new AlunoDAO();
        DAO notaDAO = new NotaDAO();

        ResultSet rsAluno = aluDAO.selectAll();
        ResultSet rsNota = notaDAO.selectAll();

        ArrayList<Aluno> alunos = new ArrayList<>();

        while (rsAluno.next()) {
            while (rsNota.next()) {

                if (rsAluno.getInt("matricula") == rsNota.getInt("matricula")) {
                    alunos.add(new Aluno(
                            rsAluno.getInt("matricula"),
                            rsAluno.getString("nome"),
                            rsAluno.getString("tipo"),
                            rsNota.getDouble("av1"),
                            rsNota.getDouble("av2"),
                            rsNota.getDouble("av3"),
                            rsNota.getDouble("avd"),
                            rsNota.getDouble("avds"),
                            rsNota.getDouble("avs"),
                            rsNota.getDouble("simulado")));
                }
            }
            rsNota = notaDAO.selectAll();
        }

        return alunos;
    }

}
