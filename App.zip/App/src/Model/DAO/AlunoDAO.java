package Model.DAO;

public class AlunoDAO extends DAO {


}
