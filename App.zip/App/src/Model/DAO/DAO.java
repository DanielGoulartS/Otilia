package Model.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class DAO {

    public Connection getConnection() throws SQLException {

        Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Alunos");
        return connection;

    }

    public void closeConnection(Connection connection) throws SQLException {
        connection.close();
    }

    public Statement getStatement() throws SQLException {

        Statement statement = getConnection().createStatement();
        return statement;
    }

    public void closeStatement(Statement statement) throws SQLException {

        statement.close();

    }

    public ResultSet selectAll() throws SQLException {
        String tabela = "";

        if (this instanceof NotaDAO) {
            tabela = "Notas";
        } else if (this instanceof AlunoDAO) {
            tabela = "Alunos";
        } else{
            return null;
        }
        Statement st = getStatement();
        ResultSet rs = st.executeQuery("Select * from " + tabela);

        return rs;

    }

}
