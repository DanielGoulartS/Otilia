
package Model.DAO;

public class NotaDAO extends DAO{
  
}
