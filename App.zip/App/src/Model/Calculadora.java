package Model;

import java.util.ArrayList;
import java.util.Arrays;

public class Calculadora {

    public static Double getMedia(Aluno aluno) {
        double media;
        double[] notas;

        switch (aluno.tipo) {
            case "e": //EaD
                if (aluno.getAv1() < aluno.getAvs()) {
                    media = aluno.getAvs() + aluno.getSimulado();
                    return media;
                } else {
                    media = aluno.getAv1() + aluno.getSimulado();
                    return media;
                }

            case "a": //Aura
                notas = new double[]{aluno.getAv1(), aluno.getAv2(), aluno.getAv3(), aluno.getAvd(), aluno.getAvds()};
                Arrays.sort(notas);
                media = (notas[4] + notas[3] + notas[2]) / 3;
                return media;

            case "p": //Presencial
            default:

                notas = new double[]{aluno.getAv1(), aluno.getAv2(), aluno.getAv3()};
                Arrays.sort(notas);
                media = (notas[2] + notas[1]) / 2;
                return media;

        }
    }

    public String verTudo(Aluno aluno) {
        return aluno.getNome() + " : "
                + aluno.getMatricula() + " : "
                + aluno.getTipo() + " : "
                + aluno.getAv1() + " : "
                + aluno.getAv2() + " : "
                + aluno.getAv3() + " : "
                + aluno.getAvd() + " : "
                + aluno.getAvds() + " : "
                + aluno.getAvs() + " : "
                + aluno.getSimulado();

    }

    public String[][] converter(ArrayList<Aluno> alunos){
        
        String[][] dados = new String[6][11];
        
        int i = 0;

        for (Aluno aluno : alunos) {

            dados[i][0] = aluno.getTipo();
            dados[i][1] = String.valueOf(aluno.getMatricula());
            dados[i][2] = aluno.getNome();
            dados[i][3] = String.valueOf(aluno.getAv1());
            dados[i][4] = String.valueOf(aluno.getAv2());
            dados[i][5] = String.valueOf(aluno.getAv3());
            dados[i][6] = String.valueOf(aluno.getAvd());
            dados[i][7] = String.valueOf(aluno.getAvds());
            dados[i][8] = String.valueOf(aluno.getAvs());
            dados[i][9] = String.valueOf(aluno.getSimulado());
            dados[i][10] = String.valueOf(Calculadora.getMedia(aluno));

            i++;

        }
        
        return dados;
        
    }
    
}
